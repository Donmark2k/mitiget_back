from rest_framework_simplejwt.tokens import Token
from .models import User
from django.contrib.auth.password_validation import validate_password
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer
from rest_framework import serializers
from rest_framework.validators import UniqueValidator

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'username', 'email']

class MyTOPS(TokenObtainPairSerializer):
    @classmethod
    def get_token(cls, user):
        token = super().get_token(user)

        token['name'] = user.profile.name
        token['username'] = user.username
        token['email'] = user.email
        token['role'] = 'user'

        return token
    

class RegistrationSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True, required=False)
    password2 = serializers.CharField(write_only=True, required=False)
    name = serializers.CharField(write_only=True, required=False)
    username = serializers.CharField(write_only=True, required=False)
    email = serializers.CharField(write_only=True) 

    class Meta:
        model = User
        fields = ['name', 'email', 'username', 'password', 'password2']

    def to_internal_value(self, data):
        data = data.copy()

        if not data.get('name'):
            data['name'] = 'John Doe'
        
        if not data.get('username'):
            data['username'] = 'johnDoe'
        
        if not data.get('password'):
            data['password'] = 'default12345'
        
        if not data.get('password2'):
            data['password2'] = 'default12345'
        
        return super().to_internal_value(data)

    def validate(self, attrs):
        if attrs['password'] != attrs['password2']:
            raise serializers.ValidationError(
                {'password':"Passwords do not match"}
            )

        # Split emails and validate each one
        emails = [email.strip() for email in attrs['email'].split(',') if email.strip()]  # Remove empty emails
        email_validator = serializers.EmailField()

        for email in emails:
            try:
                email_validator.run_validation(email)
            except serializers.ValidationError:
                raise serializers.ValidationError(
                    {'email': f"Enter a valid email address: {email}"}
                )
        
        attrs['email'] = emails  # Store the list of validated emails
        validate_password(attrs['password'])

        return attrs
     
    def create(self, validated_data):
        emails = validated_data['email']
        users = []

        for email in emails:
            user_data = validated_data.copy()
            user_data['email'] = email.strip()

            name = user_data['name']
            first_name, last_name = name.split()

            user = User.objects.create(
                first_name=first_name,
                last_name=last_name,
                username=user_data['username'],
                email=user_data['email']
            )
            user.set_password(user_data['password'])
            user.save()

            if "name" in user_data:
                user.profile.name = user_data['name']
                user.profile.role = 'user'
                user.profile.save()

            users.append(user)  # Collect each created user in the list

        return users if len(users) > 1 else users[0]