from django.urls import path
from . import views

urlpatterns = [
    path('viewBooks/', views.viewBooks, name='viewBooks'),
    path('addBooks/', views.addBooks, name='addBooks'),
    path('viewBooks/<int:id>/', views.viewBookById, name='view_book_by_id'),
    path('viewBooks/update/<int:id>/', views.updateBook, name='update_book'),

] 