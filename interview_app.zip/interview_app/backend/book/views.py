from django.shortcuts import render
from rest_framework.response import Response
from rest_framework.decorators import api_view
from book.models import Book
from .serializers import BookSerializer
from rest_framework import status
from django.shortcuts import get_object_or_404

# Create your views here.
@api_view(['GET'])
def viewBooks(request):
    books = Book.objects.all()
    serializer = BookSerializer(books, many=True)
    return Response(serializer.data)

@api_view(['GET'])
def viewBookById(request, id):
    book = get_object_or_404(Book, id=id)
    serializer = BookSerializer(book)
    return Response(serializer.data)

@api_view(['POST'])
def addBooks(request):
    serializer = BookSerializer(data=request.data)
    if serializer.is_valid():
        serializer.save()
    return Response(serializer.data)

@api_view(['PUT'])
def updateBook(request, id):
    book = get_object_or_404(Book, id=id)
    serializer = BookSerializer(book, data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)